package jogamp.openal;

import com.jogamp.common.nio.Buffers;
import com.jogamp.openal.ALException;
import com.jogamp.openal.ALCdevice;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;

/**
 * ALExt implementation.
 */
public class ALExtImpl extends ALExtAbstractImpl {

}
